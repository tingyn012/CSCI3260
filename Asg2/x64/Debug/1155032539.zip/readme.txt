	CSCI3260 Assignment 2 Keyboard / Mouse Events  

Name: NG, Ting Yuk
Student ID: 1155032539

Manipulation:
Key "q" : increase brightness of diffuse light
Key "w" : decrease brightness of diffuse light
Key "z" : increase brightness of specular light
Key "x" : decrease brightness of specular light
Key "s" : stop or continue the rotation


arrow keys "��������" : move the tank

mouse moves up : whole scene you see moves down
mouse moves left : whole scene you see moves righ