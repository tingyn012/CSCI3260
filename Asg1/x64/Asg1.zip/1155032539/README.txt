========================================================================
Contorl:
[w][a][s][d]			Move the cube
[f][r]					Scaling the cube
[g]						Rorate the pyramid

When the volume of the cube is smaller, the movement speed will higher.
When the cube is nearby the pyramid, the pyramid will rorate automatically.
==========================================================================